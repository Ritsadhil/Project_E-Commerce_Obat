<svg
    {{ $attributes->merge(['width' => '26', 'height' => '26']) }}
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
>
    <circle cx="12" cy="12" r="10" fill="none" stroke="#00B7B5" stroke-width="1"/>
    <circle cx="12" cy="12" r="9" fill="#018790" stroke="#018790" stroke-width="1"/>

    <rect x="10.7" y="7" width="2.6" height="10" fill="#F5F5F5" rx="0.4"/>
    <rect x="7" y="10.7" width="10" height="2.6" fill="#F5F5F5" rx="0.4"/>
</svg>
